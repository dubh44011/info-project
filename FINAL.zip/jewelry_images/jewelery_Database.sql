-- Create Database
CREATE DATABASE Jewelry_store;


-- Use Database
USE Jewelry_store;


-- Create MenJewelry Table:
CREATE TABLE menjewelry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image1 VARCHAR(255) DEFAULT NULL,
    image2 VARCHAR(255) DEFAULT NULL,
    image3 VARCHAR(255) DEFAULT NULL
);


-- Create WomenJewelry Table:
CREATE TABLE womenjewelry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image1 VARCHAR(255) DEFAULT NULL,
    image2 VARCHAR(255) DEFAULT NULL,
    image3 VARCHAR(255) DEFAULT NULL
);


-- Create Bills Table:
CREATE TABLE bills (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(255) NOT NULL,
    items_bought TEXT NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL
);



-- Insert Sample Data into MenJewelry Table:

INSERT INTO MenJewelry (name, price, image1, image2, image3) VALUES
('Men Ring', 150.00, 'path_to_image1.jpg', 'path_to_image2.jpg', 'path_to_image3.jpg'),
('Men Bracelet', 200.00, 'path_to_image1.jpg', 'path_to_image2.jpg', 'path_to_image3.jpg'),
('Men Necklace', 250.00, 'path_to_image1.jpg', 'path_to_image2.jpg', 'path_to_image3.jpg');
-- add further data according to your need



-- Insert Sample Data into WomenJewelry Table:

INSERT INTO WomenJewelry (name, price, image1, image2, image3) VALUES
('Women Ring', 120.00, 'path_to_image1.jpg', 'path_to_image2.jpg', 'path_to_image3.jpg'),
('Women Bracelet', 180.00, 'path_to_image1.jpg', 'path_to_image2.jpg', 'path_to_image3.jpg'),
('Women Necklace', 220.00, 'path_to_image1.jpg', 'path_to_image2.jpg', 'path_to_image3.jpg');
-- add further data according to your need

