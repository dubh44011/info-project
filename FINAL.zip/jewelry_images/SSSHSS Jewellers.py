import sys
import logging
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QComboBox, QLabel,
                             QFormLayout, QHBoxLayout, QSpinBox, QPushButton, QDialog,
                             QLineEdit, QDialogButtonBox, QTableWidget, QTableWidgetItem, QHeaderView,
                             QMessageBox)
from PyQt5.QtGui import QPixmap, QIcon, QFont
from PyQt5.QtCore import Qt
from PyQt5.QtPrintSupport import QPrinter
from PyQt5.QtGui import QTextDocument
import mysql.connector
from mysql.connector import Error
from decimal import Decimal

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Database:
    def __init__(self):
        try:
            self.connection = mysql.connector.connect(
                host='localhost',
                user='root',
                password='12345',
                database='Jewelry_store'
            )
            logging.info('Database connection established.')
        except Error as e:
            logging.error(f'Error connecting to database: {e}')
            sys.exit(1)

    def get_jewelry_items(self, table):
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(f"SELECT * FROM {table}")
            return cursor.fetchall()
        except Error as e:
            logging.error(f'Error fetching jewelry items: {e}')
            return []

    def insert_bill(self, bill_id, user_name, items_bought, total_price):
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                INSERT INTO Bills (bill_id, user_name, items_bought, total_price)
                VALUES (%s, %s, %s, %s)
            """, (bill_id, user_name, items_bought, total_price))
            self.connection.commit()
            logging.info('Bill inserted into database.')
        except Error as e:
            logging.error(f'Error inserting bill: {e}')

    def get_bill(self, bill_id):
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM Bills WHERE bill_id = %s", (bill_id,))
            return cursor.fetchone()
        except Error as e:
            logging.error(f'Error fetching bill: {e}')
            return None

class StartDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Start Shopping')
        self.setGeometry(100, 100, 400, 200)
        self.setStyleSheet("""
            QDialog {
                background-color: #f5f5f5;
                border-radius: 10px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            QLineEdit {
                padding: 5px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
            QComboBox {
                padding: 5px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
            QPushButton {
                background-color: #007bff;
                color: white;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """)

        icon = QIcon("D:/My_Projects/jewelry_images/logo.png")
        self.setWindowIcon(icon)

        layout = QVBoxLayout()

        logo_label = QLabel()
        pixmap = QPixmap("D:/My_Projects/jewelry_images/logo.png")
        logo_label.setPixmap(pixmap.scaledToWidth(200))
        logo_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(logo_label)

        store_name_label = QLabel("SSSHSS Jewelers")
        store_name_label.setAlignment(Qt.AlignCenter)
        font = store_name_label.font()
        font.setPointSize(16)
        font.setBold(True)
        store_name_label.setFont(font)
        layout.addWidget(store_name_label)

        form_layout = QFormLayout()
        self.name_input = QLineEdit()
        self.gender_combo = QComboBox()
        self.gender_combo.addItem('None')
        self.gender_combo.addItems(['Men', 'Women'])

        form_layout.addRow('Name:', self.name_input)
        form_layout.addRow('Gender:', self.gender_combo)

        layout.addLayout(form_layout)

        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept_dialog)
        self.buttons.rejected.connect(self.reject)

        layout.addWidget(self.buttons)
        self.setLayout(layout)

    def accept_dialog(self):
        if self.name_input.text().strip() == '' or self.gender_combo.currentIndex() == 0:
            QMessageBox.critical(self, 'Error', 'Please fill in all fields.')
            return
        self.accept()

class BillWindow(QWidget):
    def __init__(self, bill_content):
        super().__init__()
        self.setWindowTitle('Bill Details')
        self.setGeometry(100, 100, 400, 300)
        self.setStyleSheet("""
            QWidget {
                background-color: #ffffff;
                border-radius: 10px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
        """)
        icon = QIcon("D:/My_Projects/jewelry_images/logo.png")
        self.setWindowIcon(icon)

        layout = QVBoxLayout()

        self.bill_label = QLabel()
        self.bill_label.setTextFormat(Qt.RichText)
        self.bill_label.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.bill_label.setOpenExternalLinks(True)
        self.bill_label.setText(bill_content)
        self.bill_label.setFont(QFont("Arial", 12))

        layout.addWidget(self.bill_label)

        self.setLayout(layout)

class JewelryBillGenerator(QWidget):
    def __init__(self, name, gender):
        super().__init__()

        self.name = name
        self.gender = gender

        self.setWindowTitle(f'{name}\'s Jewelry Shopping')
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("""
            QWidget {
                background-color: #e0f7fa;
                border-radius: 10px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            QComboBox, QSpinBox {
                padding: 5px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
            QPushButton {
                background-color: #007bff;
                color: white;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
            QTableWidget {
                background-color: #ffffff;
                border-radius: 10px;
            }
        """)
        icon = QIcon("D:/My_Projects/jewelry_images/logo.png")
        self.setWindowIcon(icon)

        self.db = Database()
        self.cart = []

        self.layout = QVBoxLayout()

        if self.gender == 'Men':
            self.jewelry_items = self.db.get_jewelry_items('MenJewelry')
        else:
            self.jewelry_items = self.db.get_jewelry_items('WomenJewelry')

        self.create_jewelry_section(self.gender, self.jewelry_items)

        self.cart_table = QTableWidget()
        self.cart_table.setColumnCount(5)
        self.cart_table.setHorizontalHeaderLabels(['Item', 'Unit Price', 'Quantity', 'Total Price', 'Remove'])
        self.cart_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.layout.addWidget(self.cart_table)

        self.total_label = QLabel('Total: Rs.0.00')
        self.total_label.setFont(QFont("Arial", 16, QFont.Bold))
        self.layout.addWidget(self.total_label)

        self.generate_bill_button = QPushButton('Generate Bill')
        self.generate_bill_button.clicked.connect(self.generate_bill)
        self.layout.addWidget(self.generate_bill_button)

        self.setLayout(self.layout)

    def create_jewelry_section(self, label_text, items):
        form_layout = QFormLayout()
        label = QLabel(f'{label_text} Jewelry:')
        combo = QComboBox()
        combo.addItem('', None)
        for item in items:
            combo.addItem(item['name'], item)

        quantity_spinbox = QSpinBox()
        quantity_spinbox.setRange(1, 99)

        add_button = QPushButton('Add to Cart')
        add_button.clicked.connect(lambda: self.add_to_cart(combo, quantity_spinbox))

        form_layout.addRow(label, combo)
        form_layout.addRow('Quantity:', quantity_spinbox)
        form_layout.addRow(add_button)

        self.layout.addLayout(form_layout)

        image_layout = QHBoxLayout()
        for i in range(3):
            image_label = QLabel()
            image_layout.addWidget(image_label)

        combo.currentIndexChanged.connect(lambda: self.update_images(combo, image_layout))
        self.layout.addLayout(image_layout)

    def add_to_cart(self, combo, quantity_spinbox):
        if combo.currentData():
            item = combo.currentData()
            quantity = quantity_spinbox.value()

            for i, (cart_item, cart_quantity) in enumerate(self.cart):
                if cart_item['id'] == item['id']:
                    self.cart[i] = (cart_item, cart_quantity + quantity)
                    self.update_cart_table()
                    self.update_total()
                    return
            
            self.cart.append((item, quantity))
            self.update_cart_table()
            self.update_total()

    def update_cart_table(self):
        self.cart_table.setRowCount(len(self.cart))
        for row, (item, quantity) in enumerate(self.cart):
            self.cart_table.setItem(row, 0, QTableWidgetItem(item['name']))
            self.cart_table.setItem(row, 1, QTableWidgetItem(f"Rs.{item['price']:.2f}"))

            quantity_spinbox = QSpinBox()
            quantity_spinbox.setRange(1, 99)
            quantity_spinbox.setValue(quantity)
            quantity_spinbox.valueChanged.connect(lambda value, row=row: self.update_quantity(row, value))
            self.cart_table.setCellWidget(row, 2, quantity_spinbox)

            self.cart_table.setItem(row, 3, QTableWidgetItem(f"Rs.{item['price'] * quantity:.2f}"))

            remove_button = QPushButton('Remove')
            remove_button.clicked.connect(lambda row=row: self.remove_from_cart(row))
            self.cart_table.setCellWidget(row, 4, remove_button)

    def update_quantity(self, row, value):
        self.cart[row] = (self.cart[row][0], value)
        self.update_cart_table()
        self.update_total()

    def remove_from_cart(self, row):
        del self.cart[row]
        self.update_cart_table()
        self.update_total()

    def update_total(self):
        total = 0.0
        for item, quantity in self.cart:
            total += float(item['price']) * quantity
        self.total_label.setText(f'Total: Rs.{total:.2f}')

    def update_images(self, combo, image_layout):
        for i in range(3):
            image_label = image_layout.itemAt(i).widget()
            if combo.currentData():
                image_path = combo.currentData()[f'image{i+1}']
                pixmap = QPixmap(image_path)
                image_label.setPixmap(pixmap.scaled(100, 100))
            else:
                image_label.clear()

    def generate_bill(self):
        try:
            cursor = self.db.connection.cursor()
            cursor.execute("SELECT MAX(bill_id) FROM Bills")
            result = cursor.fetchone()
            max_bill_id = result[0] if result[0] is not None else 0
            bill_number = max_bill_id + 1

            items_bought = ""
            total_price = 0.0
            for item, quantity in self.cart:
                item_price = float(item['price']) * quantity
                items_bought += f"<p>{item['name']} (x{quantity}) Rs.{item['price']:.2f}</p>"
                total_price += item_price

            shop_name = "SSSHSS Jewelers"
            shop_address = "Vidyagiri, Prashanti Nilayam, Anantapur,\n Puttaparthi, Andhra Pradesh 515134"

            bill_content = f"""
            <h1>{shop_name}</h1>
            <p><strong>{shop_address}</strong> </p>
            <br>
            <br>

            <p><strong>Bill Details:</strong></p>
            <p><strong>Bill Number:</strong> {bill_number}</p>
            <p><strong>Name:</strong> {self.name}</p>
            <p><strong>Items Bought:</strong></p>
            {items_bought}
            <p><strong>Total Price:</strong> <span style="color:red">Rs.{total_price:.2f}</span></p>

            <br>
            <br>

            <h3>Thank you for Shopping with us!! Please visit Again...</h3>
            """

            self.db.insert_bill(bill_number, self.name, items_bought, total_price)

            self.bill_window = BillWindow(bill_content)
            self.bill_window.show()

            document = QTextDocument()
            document.setHtml(bill_content)
            printer = QPrinter(QPrinter.HighResolution)
            pdf_filename = f"bill_{bill_number}_{self.name.replace(' ', '_')}.pdf"
            printer.setOutputFileName(pdf_filename)
            printer.setOutputFormat(QPrinter.PdfFormat)
            document.print_(printer)

            logging.info(f'Bill generated and saved as {pdf_filename}.')
        except Exception as e:
            logging.error(f'Error generating bill: {e}')
            QMessageBox.critical(self, 'Error', 'An error occurred while generating the bill.')

class ExtractBillWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Extract Bill')
        self.setGeometry(100, 100, 400, 300)
        self.setStyleSheet("""
            QWidget {
                background-color: #f5f5f5;
                border-radius: 10px;
            }
            QLineEdit {
                padding: 5px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
            QPushButton {
                background-color: #007bff;
                color: white;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
        """)
        icon = QIcon("D:/My_Projects/jewelry_images/logo.png")
        self.setWindowIcon(icon)

        self.db = Database()

        self.layout = QVBoxLayout()

        self.bill_number_input = QLineEdit()
        self.bill_number_input.setPlaceholderText('Enter Bill Number')
        self.layout.addWidget(self.bill_number_input)

        self.search_button = QPushButton('Search and display bill')
        self.search_button.clicked.connect(self.search_bill)
        self.layout.addWidget(self.search_button)

        self.bill_details_label = QLabel()
        self.layout.addWidget(self.bill_details_label)

        self.setLayout(self.layout)

    def search_bill(self):
        bill_number = self.bill_number_input.text().strip()
        if not bill_number.isdigit():
            QMessageBox.critical(self, 'Error', 'Please enter a valid bill number.')
            return

        bill = self.db.get_bill(bill_number)
        if bill:
            bill_content = f"""
            <h1>Bill Details</h1>
            <p><strong>Bill Number:</strong> {bill['bill_id']}</p>
            <p><strong>Name:</strong> {bill['user_name']}</p>
            <p><strong>Items Bought:</strong> {bill['items_bought']}</p>
            <p><strong>Total Price:</strong> <span style="color:red">Rs.{bill['total_price']:.2f}</span></p>
            """
            self.bill_details_label.setText(bill_content)
        else:
            self.bill_details_label.setText('Bill not found.')
            logging.info(f'Bill number {bill_number} not found.')

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Jewelry Store')
        self.setGeometry(100, 100, 400, 300)
        self.setStyleSheet("""
            QWidget {
                background-color: #fff0f5;
                border-radius: 10px;
            }
            QLabel {
                font-size: 16px;
                color: #333;
            }
            QPushButton {
                background-color: #ff1493;
                color: white;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #c71585;
            }
        """)

        icon = QIcon("D:/My_Projects/jewelry_images/logo.png")
        self.setWindowIcon(icon)

        layout = QVBoxLayout()

        store_name_label = QLabel("SSSHSS Jewelers", self)
        store_name_label.setFont(QFont("Arial", 16, QFont.Bold))
        layout.addWidget(store_name_label, alignment=Qt.AlignCenter)

        logo_image = QLabel(self)
        pixmap = QPixmap("D:/My_Projects/jewelry_images/logo.png")
        pixmap = pixmap.scaled(200, 200, Qt.KeepAspectRatio)
        logo_image.setPixmap(pixmap)
        layout.addWidget(logo_image, alignment=Qt.AlignCenter)

        buy_button = QPushButton('Buy', self)
        buy_button.clicked.connect(self.show_start_dialog)
        layout.addWidget(buy_button, alignment=Qt.AlignCenter)

        extract_bill_button = QPushButton('Extract Bill', self)
        extract_bill_button.clicked.connect(self.show_extract_bill_window)
        layout.addWidget(extract_bill_button, alignment=Qt.AlignCenter)

        self.setLayout(layout)

    def show_start_dialog(self):
        dialog = StartDialog()
        if dialog.exec() == QDialog.Accepted:
            name = dialog.name_input.text()
            gender = dialog.gender_combo.currentText()
            window = JewelryBillGenerator(name, gender)
            window.show()

    def show_extract_bill_window(self):
        self.extract_bill_window = ExtractBillWindow()
        self.extract_bill_window.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)

    main_window = MainWindow()
    main_window.show()

    sys.exit(app.exec_())
